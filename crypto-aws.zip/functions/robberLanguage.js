const { sendResponse } = require("../responses/response");


/*This should return the string in the form of The Robber
Language, from Astrid Lindgrens books about Kalle Blomkvist
Each consonant is doubled and an 'O' is inserted in between.
Example 'Hello world' becomes 'Hohelollolo wowororloldod'*/
function robberEncrypt(key, message) {

}


function robberDecrypt(key, message) {

}

module.exports = { robberEncrypt, robberDecrypt };